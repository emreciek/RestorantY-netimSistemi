#include "../../include/services/RestoranServisi.hpp"
#include "../../src/utils/TarihUtils.h" // Tarih yardımcıları eklendi
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <unordered_map>

// Kurucu
RestoranServisi::RestoranServisi(
    Depo<Masa>& masaDepo, Depo<Garson>& garsonDepo,
    Depo<MenuKategori>& kategoriDepo, Depo<MenuItem>& menuItemDepo,
    Depo<Siparis>& siparisDepo, Depo<SiparisKalemi>& siparisKalemiDepo,
    Depo<Rezervasyon>& rezervasyonDepo
) : _masaDepo(masaDepo), _garsonDepo(garsonDepo),
    _kategoriDepo(kategoriDepo), _menuItemDepo(menuItemDepo),
    _siparisDepo(siparisDepo), _siparisKalemiDepo(siparisKalemiDepo),
    _rezervasyonDepo(rezervasyonDepo) {}

// Masa ekleme
void RestoranServisi::masaEkle(int numara, int kapasite, const std::string& konum) {
    auto masa = std::make_shared<Masa>(0, numara, kapasite, konum, "Boş");
    _masaDepo.ekle(masa);
}

// Menü item ekleme
void RestoranServisi::menuItemEkle(const std::string& ad, const std::string& aciklama,
                                   double fiyat, int kategori_id, int hazirlik_suresi) {
    auto item = std::make_shared<MenuItem>(0, ad, aciklama, fiyat, kategori_id, hazirlik_suresi);
    _menuItemDepo.ekle(item);
}

// Sipariş oluşturma
int RestoranServisi::siparisOlustur(int masa_id, int garson_id) {
    std::string tarih = TarihUtils::bugunTarihi(); // Dinamik tarih
    auto siparis = std::make_shared<Siparis>(0, masa_id, garson_id, tarih, "Açık", 0.0);
    _siparisDepo.ekle(siparis);
    return siparis->get_id();
}

// Siparişe item ekleme
void RestoranServisi::sipariseItemEkle(int siparis_id, int menu_item_id, int miktar, const std::string& notlar) {
    auto siparisKalemi = std::make_shared<SiparisKalemi>(0, siparis_id, menu_item_id, miktar, notlar);
    _siparisKalemiDepo.ekle(siparisKalemi);

    auto menuItem = _menuItemDepo.getir(menu_item_id);
    auto siparis = _siparisDepo.getir(siparis_id);
    double yeniToplam = siparis->getToplam() + (menuItem->getFiyat() * miktar);
    siparis->setToplam(yeniToplam);
    _siparisDepo.guncelle(siparis);
}

// Siparişi kapatma
void RestoranServisi::siparisKapat(int siparis_id) {
    auto siparis = _siparisDepo.getir(siparis_id);
    siparis->setDurum("Kapalı");
    _siparisDepo.guncelle(siparis);
}

// Hesap yazdırma
std::string RestoranServisi::hesapYazdir(int siparis_id) {
    auto siparis = _siparisDepo.getir(siparis_id);
    std::ostringstream oss;
    oss << "Siparis #" << siparis->get_id() << " - Masa: " << siparis->getMasaId() << "\n";
    oss << "Durum: " << siparis->getDurum() << "\n";
    oss << "Toplam: " << siparis->getToplam() << " TL\n";
    return oss.str();
}

// Rezervasyon yapma
void RestoranServisi::rezervasyonYap(int masa_id, const std::string& musteri_adi,
                                     const std::string& telefon, const std::string& tarih_saat,
                                     int kisi_sayisi) {
    auto rezervasyon = std::make_shared<Rezervasyon>(0, masa_id, musteri_adi, telefon, tarih_saat, kisi_sayisi);
    _rezervasyonDepo.ekle(rezervasyon);

    auto masa = _masaDepo.getir(masa_id);
    masa->setDurum("Rezerve");
    _masaDepo.guncelle(masa);
}

// Müsait masaları getir
std::vector<std::shared_ptr<Masa>> RestoranServisi::musaitMasalariGetir() {
    return _masaDepo.ara([](const std::shared_ptr<Masa>& m) {
        return m->getDurum() == "Boş";
    });
}

// Günlük ciro hesapla
double RestoranServisi::gunlukCiroHesapla(const std::string& tarih) {
    double toplam = 0.0;
    auto siparisler = _siparisDepo.ara([&](const std::shared_ptr<Siparis>& s) {
        return s->getDurum() == "Kapalı" &&
               TarihUtils::tarihiAyristir(s->getTarihSaat(), *(new int), *(new int), *(new int)) &&
               s->getTarihSaat().substr(0, 10) == tarih;
    });
    for (auto& s : siparisler) {
        toplam += s->getToplam();
    }
    return toplam;
}

// En popüler yemekler
std::vector<std::shared_ptr<MenuItem>> RestoranServisi::enPopulerYemekler(int limit) {
    std::unordered_map<int, int> sayac;
    auto kalemler = _siparisKalemiDepo.tumunu();
    for (auto& k : kalemler) {
        sayac[k->getMenuItemId()] += k->getMiktar();
    }

    std::vector<std::pair<int, int>> populer(sayac.begin(), sayac.end());
    std::sort(populer.begin(), populer.end(), [](auto& a, auto& b) {
        return a.second > b.second;
    });

    std::vector<std::shared_ptr<MenuItem>> sonuc;
    for (int i = 0; i < limit && i < populer.size(); ++i) {
        sonuc.push_back(_menuItemDepo.getir(populer[i].first));
    }
    return sonuc;
}

// Garson performansı
GarsonPerformans RestoranServisi::garsonPerformansi(int garson_id) {
    GarsonPerformans p{0, 0.0, 0.0};
    auto siparisler = _siparisDepo.ara([&](const std::shared_ptr<Siparis>& s) {
        return s->getGarsonId() == garson_id;
    });
    p.toplam_siparis = siparisler.size();
    for (auto& s : siparisler) {
        p.toplam_ciro += s->getToplam();
    }
    if (p.toplam_siparis > 0) {
        p.ortalama_siparis = p.toplam_ciro / p.toplam_siparis;
    }
    return p;
}