#include "entities/MenuKategori.hpp"
#include <sstream>
// Varsayılan ilklendirici
MenuKategori::MenuKategori()
    // TODO: Implementasyon
:id(0), ad(""), aciklama("") {}

// Parametreli ilklendirici
MenuKategori::MenuKategori(int id, const std::string& ad, const std::string& aciklama)
    // TODO: Implementasyon
:id(id), ad(ad), aciklama(aciklama) {}

// Kopya ilklendirici
MenuKategori::MenuKategori(const MenuKategori& other)
    // TODO: Implementasyon
:id(other.id), ad(other.ad), aciklama(other.aciklama) {}

// Sonlandırıcı
MenuKategori::~MenuKategori()=default;
    // TODO: Implementasyon
//Getter ve Setterlar
int MenuKategori::getId() const {return id;}
std::string MenuKategori::getAd() const {return ad;}
std::string MenuKategori::getAciklama() const {return aciklama;}
void MenuKategori::setId(int id) {this->id = id;}
void MenuKategori::setAd(const std::string& ad) {this->ad = ad;}
void MenuKategori::setAciklama(const std::string& aciklama) {this->aciklama = aciklama;}

// Depo şablonu için zorunlu metod
int MenuKategori::get_id() const {
    // TODO: Implementasyon
    return id;
}
//Debug için gerekli alan
std::string MenuKategori::toString() const {
    std::ostringstream oss;
    oss << "[MenuKategori: " << id;
    oss << ", ad: " << ad;
    oss << ", aciklama: " << aciklama;
    oss << "]";
    return oss.str();
}