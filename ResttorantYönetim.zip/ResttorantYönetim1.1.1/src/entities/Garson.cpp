#include "entities/Garson.hpp"
#include <sstream>

// Varsayılan ilklendirici
Garson::Garson()
    : id(0), sicilNo(""), adSoyad(""), telefon(""), vardiya("") {
    // TODO: Implementasyon
}

// Parametreli ilklendirici
Garson::Garson(int id, const std::string& sicil_no, const std::string& ad_soyad,
       const std::string& telefon, const std::string& vardiya)
    : id(id), sicilNo(sicil_no), adSoyad(ad_soyad), telefon(telefon), vardiya(vardiya) {
    // TODO: Implementasyon
}

// Kopya ilklendirici
Garson::Garson(const Garson& other)
    : id(other.id), sicilNo(other.sicilNo), adSoyad(other.adSoyad),
      telefon(other.telefon), vardiya(other.vardiya) {
    // TODO: Implementasyon
}

// Getter Setterlar
int Garson::getId() const {
    return id;
}
std::string Garson::getSicilNo() const {
    return sicilNo;
}
std::string Garson::getAdSoyad() const {
    return adSoyad;
}
std::string Garson::getTelefon() const {
    return telefon;
}
std::string Garson::getVardiya() const {
    return vardiya;
}
void Garson::setId(int id) {
    this->id = id;
}
void Garson::setSicilNo(const std::string& sicilNo) {
    this->sicilNo = sicilNo;
}
void Garson::setAdSoyad(const std::string& adSoyad) {
    this->adSoyad = adSoyad;
}
void Garson::setTelefon(const std::string& telefon) {
    this->telefon = telefon;
}
void Garson::setVardiya(const std::string& vardiya) {
    this->vardiya = vardiya;
}

// Sonlandırıcı
Garson::~Garson() = default;
// TODO: Implementasyon

// Depo şablonu için zorunlu metod
int Garson::get_id() const {
    // TODO: Implementasyon
    return id;
}

// Debug amaçlı
std::string Garson::toString() const {
    std::ostringstream oss;
    oss << "Garson[ID=" << id
        << ", SicilNo=" << sicilNo
        << ", AdSoyad=" << adSoyad
        << ", Telefon=" << telefon
        << ", Vardiya=" << vardiya
        << "]";
    return oss.str();
}