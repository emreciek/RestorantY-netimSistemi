#include "entities/MenuItem.hpp"
#include <sstream>
// Varsayılan ilklendirici
MenuItem::MenuItem()
    // TODO: Implementasyon
:id(0), ad(""), aciklama(""), fiyat(0), kategori_id(0), hazirlik_suresi(0){}

// Parametreli ilklendirici
MenuItem::MenuItem(int id, const std::string& ad, const std::string& aciklama,
         double fiyat, int kategori_id, int hazirlik_suresi)
    // TODO: Implementasyon
:id(id), ad(ad), aciklama(aciklama), fiyat(fiyat), kategori_id(kategori_id),
hazirlik_suresi(hazirlik_suresi){}


// Kopya ilklendirici
MenuItem::MenuItem(const MenuItem& other)
    // TODO: Implementasyon
:id(other.id), ad(other.ad), aciklama(other.aciklama), fiyat(other.fiyat),
kategori_id(other.kategori_id), hazirlik_suresi(other.hazirlik_suresi){}

// Sonlandırıcı
MenuItem::~MenuItem() = default;
    // TODO: Implementasyon
//Getter ve Setterlar
int MenuItem::getId() const {return id;}
int MenuItem::getKategoriId() const {return kategori_id;}
int MenuItem::getHazirlikSuresi() const {return hazirlik_suresi;}
double MenuItem::getFiyat() const {return fiyat;}
std::string MenuItem::getAciklama() const {return aciklama;}
std::string MenuItem::getAd() const {return ad;}
void MenuItem::setId(int id) {this->id = id;}
void MenuItem::setKategoriId(int kategori_id) {this->kategori_id = kategori_id;}
void MenuItem::setHazirlikSuresi(int hazirlik_suresi) {this->hazirlik_suresi = hazirlik_suresi;}
void MenuItem::setFiyat(double fiyat) {this->fiyat = fiyat;}
void MenuItem::setAciklama(const std::string& aciklama) {this->aciklama = aciklama;}
void MenuItem::setAd(const std::string& ad) {this->ad = ad;}

// Depo şablonu için zorunlu metod
int MenuItem::get_id() const {
    // TODO: Implementasyon
    return id;
}
//Debug için gerekli alan
std::string MenuItem::toString() const {
    std::ostringstream oss;
    oss << "[MenuItem: " << id;
    oss << ", ad: " << ad;
    oss << ", fiyat: " << fiyat;
    oss << ", kategori_id: " << kategori_id;
    oss << ", hazirlik_suresi: " << hazirlik_suresi;
    oss << ", aciklama: " << aciklama;
    oss << "]";
    return oss.str();
}
