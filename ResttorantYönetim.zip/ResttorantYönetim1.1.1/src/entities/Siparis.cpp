#include "entities/Siparis.hpp"
#include <sstream>
// Varsayılan ilklendirici
Siparis::Siparis()
    // TODO: Implementasyon
:id(0), masa_id(0), garson_id(0), tarih_saat(""), durum(""), toplam(0){}

// Parametreli ilklendirici
Siparis::Siparis(int id, int masa_id, int garson_id, const std::string& tarih_saat,
        const std::string& durum, double toplam)
    // TODO: Implementasyon
:id(id), masa_id(masa_id), garson_id(garson_id), tarih_saat(tarih_saat), durum(durum), toplam(toplam){}

// Kopya ilklendirici
Siparis::Siparis(const Siparis& other)
    // TODO: Implementasyon
:id(other.id), masa_id(other.masa_id), garson_id(other.garson_id),
tarih_saat(other.tarih_saat), durum(other.durum), toplam(other.toplam){}

// Sonlandırıcı
Siparis::~Siparis() =default;
    // TODO: Implementasyon
//Getter ve Setterlar
int Siparis::getId() const {return id;}
int Siparis::getMasaId() const{return masa_id;}
std::string Siparis::getDurum() const {return durum;}
std::string Siparis::getTarihSaat() const {return tarih_saat;}
int Siparis::getGarsonId() const {return garson_id;}
double Siparis::getToplam() const {return toplam;}

void Siparis::setId(int id) {this->id = id;}
void Siparis::setToplam(double toplam) {this->toplam = toplam;}
void Siparis::setGarsonId(int garson_id) {this->garson_id = garson_id;}
void Siparis::setDurum(const std::string& durum) {this->durum = durum;}
void Siparis::setMasaId(int masa_id) {this->masa_id = masa_id;}
void Siparis::setTarihSaat(const std::string& tarih_saat) {this->tarih_saat = tarih_saat;}



// Depo şablonu için zorunlu metod
int Siparis::get_id() const {
    // TODO: Implementasyon
    return id;
}
//Debug için gerekli alan
std::string Siparis::toString() const {
    std::ostringstream oss;
    oss << "[Siparis: " << id;
    oss << ", masa_id: " << masa_id;
    oss << ", garson_id: " << garson_id;
    oss << ", tarih_saat: " << tarih_saat;
    oss << ", durum: " << durum;
    oss << ", toplam: " << toplam;
    oss << "]";
    return oss.str();
}