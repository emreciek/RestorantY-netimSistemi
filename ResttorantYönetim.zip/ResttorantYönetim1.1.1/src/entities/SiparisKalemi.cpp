#include "entities/SiparisKalemi.hpp"
#include <sstream>
// Varsayılan ilklendirici
SiparisKalemi::SiparisKalemi()
    // TODO: Implementasyon
:id(0), siparis_id(0), menu_item_id(0), miktar(0), notlar("") {}

// Parametreli ilklendirici
SiparisKalemi::SiparisKalemi(int id, int siparis_id, int menu_item_id, int miktar, const std::string& notlar)
    // TODO: Implementasyon
:id(id), siparis_id(siparis_id), menu_item_id(menu_item_id), miktar(miktar), notlar(notlar) {}

// Kopya ilklendirici
SiparisKalemi::SiparisKalemi(const SiparisKalemi& other)
    // TODO: Implementasyon
:id(other.id), siparis_id(other.siparis_id), menu_item_id(other.menu_item_id), miktar(other.miktar), notlar(other.notlar) {}

// Sonlandırıcı
SiparisKalemi::~SiparisKalemi()=default;
    // TODO: Implementasyon
//Getter ve Setterlar
int SiparisKalemi::getId() const {return id;}
int SiparisKalemi::getSiparisId() const {return siparis_id;}
int SiparisKalemi::getMenuItemId() const {return menu_item_id;}
int SiparisKalemi::getMiktar() const {return miktar;}
std::string SiparisKalemi::getNotlar() const {return notlar;}
void SiparisKalemi::setId(int id) {this->id = id;}
void SiparisKalemi::setSiparisId(int siparis_id) {this->siparis_id = siparis_id;}
void SiparisKalemi::setMenuItemId(int menu_item_id) {this->menu_item_id = menu_item_id;}
void SiparisKalemi::setMiktar(int miktar) {this->miktar = miktar;}

// Depo şablonu için zorunlu metod
int SiparisKalemi::get_id() const {
    // TODO: Implementasyon
    return id;
}
//Debug için gerekşi alan
std::string SiparisKalemi::toString() const {
    std::ostringstream oss;
    oss << "[SiparisKalemi: " << id;
    oss << ", siparis_id: " << siparis_id;
    oss << ", menu_item_id: " << menu_item_id;
    oss << ", miktar: " << miktar;
    oss << ", notlar: " << notlar;
    oss << "]";
    return oss.str();
}