#include "entities/Masa.hpp"
#include <sstream>
// Varsayılan ilklendirici
Masa::Masa()
    // TODO: Implementasyon
:id(0), numara(0), kapasite(0), konum(""), durum(""){}


// Parametreli ilklendirici
Masa::Masa(int id, int numara, int kapasite, const std::string& konum, const std::string& durum)
    // TODO: Implementasyon
: id(id), numara(numara), kapasite(kapasite), konum(konum), durum(durum){}

// Kopya ilklendirici
Masa::Masa(const Masa& other)
    // TODO: Implementasyon
:id(other.id), numara(other.numara), kapasite(other.kapasite), konum(other.konum), durum(other.durum){}

// Sonlandırıcı
Masa::~Masa() =default;
    // TODO: Implementasyon
//Getter Setterlar
int Masa::getId() const {return id;}
int Masa::getNumara() const {return numara;}
int Masa::getKapasite() const {return kapasite;}
std::string Masa::getKonum() const {return konum;}
std::string Masa::getDurum() const {return durum;}
void Masa::setId(int id) {this->id = id;}
void Masa::setNumara(int numara) {this->numara = numara;}
void Masa::setKapasite(int kapasite) {this->kapasite = kapasite;}
void Masa::setKonum(const std::string& konum) {this->konum = konum;}
void Masa::setDurum(const std::string& durum) {this->durum = durum;}

// Depo şablonu için zorunlu metod
int Masa::get_id() const {
    // TODO: Implementasyon
    return id;
}
//Debug amaçlı
std::string Masa::toString() const {
    std::ostringstream oss;
    oss << "[Masa: " << numara;
    oss << ", kapasite: " << kapasite;
    oss << ", konum: " << konum;
    oss << ", durum: " << durum;
    oss <<"]";

    return oss.str();
}
