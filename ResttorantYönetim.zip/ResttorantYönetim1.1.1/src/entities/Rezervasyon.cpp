#include "entities/Rezervasyon.hpp"
#include <sstream>
// Varsayılan ilklendirici
Rezervasyon::Rezervasyon()
    // TODO: Implementasyon
:id(0), masa_id(0), musteri_adi(""), telefon(""), tarih_saat(""), kisi_sayisi(0){}

// Parametreli ilklendirici
Rezervasyon::Rezervasyon(int id, int masa_id, const std::string& musteri_adi, const std::string& telefon,
            const std::string& tarih_saat, int kisi_sayisi)
    // TODO: Implementasyon
:id(id), masa_id(masa_id), musteri_adi(musteri_adi), telefon(telefon), tarih_saat(tarih_saat), kisi_sayisi(kisi_sayisi){}

// Kopya ilklendirici
Rezervasyon::Rezervasyon(const Rezervasyon& other)
    // TODO: Implementasyon
:id(other.id), masa_id(other.masa_id), musteri_adi(other.musteri_adi), telefon(other.telefon), tarih_saat(other.tarih_saat), kisi_sayisi(other.kisi_sayisi){}

// Sonlandırıcı
Rezervasyon::~Rezervasyon() =default;
    // TODO: Implementasyon
//Getter ve Setterlar
int Rezervasyon::getId() const {return id;}
int Rezervasyon::getMasaId() const {return masa_id;}
std::string Rezervasyon::getMusteriAdi() const {return musteri_adi;}
std::string Rezervasyon::getTelefon() const {return telefon;}
std::string Rezervasyon::getTarihSaat() const {return tarih_saat;}
int Rezervasyon::getKisiSayisi() const {return kisi_sayisi;}
void Rezervasyon::setId(int id) {this->id = id;}
void Rezervasyon::setMasaId(int masa_id) {this->masa_id = masa_id;}
void Rezervasyon::setMusteriAdi(const std::string& musteri_adi) {this->musteri_adi = musteri_adi;}
void Rezervasyon::setTelefon(const std::string& telefon) {this->telefon = telefon;}
void Rezervasyon::setTarihSaat(const std::string& tarih_saat) {this->tarih_saat = tarih_saat;}
void Rezervasyon::setKisiSayisi(int kisi_sayisi) {this->kisi_sayisi = kisi_sayisi;}

// Depo şablonu için zorunlu metod
int Rezervasyon::get_id() const {
    // TODO: Implementasyon
    return id;
}
//Debug için gerekli alan
std::string Rezervasyon::toString() const {
    std::ostringstream oss;
    oss << "[Rezervasyon: " << id;
    oss << ", masa_id: " << masa_id;
    oss << ", musteri_adi: " << musteri_adi;
    oss << ", telefon: " << telefon;
    oss << ", tarih_saat: " << tarih_saat;
    oss << ", kisi_sayisi: " << kisi_sayisi;
    oss << "]";
    return oss.str();
}
