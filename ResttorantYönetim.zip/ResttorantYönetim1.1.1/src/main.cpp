#include <iostream>
#include <memory>
#include <string>
#include "../include/repositories/Depo.hpp"
#include "../include/entities/Masa.hpp"
#include "../include/entities/Garson.hpp"
#include "../include/entities/MenuKategori.hpp"
#include "../include/entities/MenuItem.hpp"
#include "../include/entities/Siparis.hpp"
#include "../include/entities/SiparisKalemi.hpp"
#include "../include/entities/Rezervasyon.hpp"
#include "../include/services/RestoranServisi.hpp"

using namespace std;

void menuYazdir() {
    cout << "\n=== RESTORAN YONETIM SISTEMI ===\n";
    cout << "1. Masa ekle\n";
    cout << "2. Menu ogesi ekle\n";
    cout << "3. Siparis olustur\n";
    cout << "4. Siparise urun ekle\n";
    cout << "5. Siparisi kapat\n";
    cout << "6. Hesap yazdir\n";
    cout << "7. Rezervasyon yap\n";
    cout << "8. Musait masalari listele\n";
    cout << "9. Gunluk ciro hesapla\n";
    cout << "10. En populer yemekleri listele\n";
    cout << "11. Garson performansi\n";
    cout << "0. Cikis\n";
    cout << "Seciminiz: ";
}

int main() {
    Depo<Masa> masaDepo;
    Depo<Garson> garsonDepo;
    Depo<MenuKategori> kategoriDepo;
    Depo<MenuItem> menuItemDepo;
    Depo<Siparis> siparisDepo;
    Depo<SiparisKalemi> siparisKalemiDepo;
    Depo<Rezervasyon> rezervasyonDepo;

    RestoranServisi servis(masaDepo, garsonDepo, kategoriDepo, menuItemDepo,
                           siparisDepo, siparisKalemiDepo, rezervasyonDepo);

    int secim;
    do {
        menuYazdir();
        cin >> secim;

        switch (secim) {
            case 1: {
                int numara, kapasite;
                string konum;
                cout << "Masa numarasi: "; cin >> numara;
                cout << "Kapasite: "; cin >> kapasite;
                cout << "Konum: "; cin.ignore(); getline(cin, konum);
                servis.masaEkle(numara, kapasite, konum);
                cout << "Masa eklendi.\n";
                break;
            }
            case 2: {
                string ad, aciklama;
                double fiyat;
                int kategori_id, hazirlik;
                cout << "Urun adi: "; cin.ignore(); getline(cin, ad);
                cout << "Aciklama: "; getline(cin, aciklama);
                cout << "Fiyat: "; cin >> fiyat;
                cout << "Kategori ID: "; cin >> kategori_id;
                cout << "Hazirlik suresi: "; cin >> hazirlik;
                servis.menuItemEkle(ad, aciklama, fiyat, kategori_id, hazirlik);
                cout << "Menu ogesi eklendi.\n";
                break;
            }
            case 3: {
                int masa_id, garson_id;
                cout << "Masa ID: "; cin >> masa_id;
                cout << "Garson ID: "; cin >> garson_id;
                int siparis_id = servis.siparisOlustur(masa_id, garson_id);
                cout << "Siparis olusturuldu. ID: " << siparis_id << endl;
                break;
            }
            case 4: {
                int siparis_id, menu_item_id, miktar;
                string notlar;
                cout << "Siparis ID: "; cin >> siparis_id;
                cout << "Menu ogesi ID: "; cin >> menu_item_id;
                cout << "Miktar: "; cin >> miktar;
                cout << "Notlar: "; cin.ignore(); getline(cin, notlar);
                servis.sipariseItemEkle(siparis_id, menu_item_id, miktar, notlar);
                cout << "Urun siparise eklendi.\n";
                break;
            }
            case 5: {
                int siparis_id;
                cout << "Siparis ID: "; cin >> siparis_id;
                servis.siparisKapat(siparis_id);
                cout << "Siparis kapatildi.\n";
                break;
            }
            case 6: {
                int siparis_id;
                cout << "Siparis ID: "; cin >> siparis_id;
                cout << servis.hesapYazdir(siparis_id) << endl;
                break;
            }
            case 7: {
                int masa_id, kisi;
                string musteri, tel, tarih;
                cout << "Masa ID: "; cin >> masa_id;
                cout << "Musteri adi: "; cin.ignore(); getline(cin, musteri);
                cout << "Telefon: "; getline(cin, tel);
                cout << "Tarih (YYYY-MM-DD HH:MM): "; getline(cin, tarih);
                cout << "Kisi sayisi: "; cin >> kisi;
                servis.rezervasyonYap(masa_id, musteri, tel, tarih, kisi);
                cout << "Rezervasyon yapildi.\n";
                break;
            }
            case 8: {
                auto masalar = servis.musaitMasalariGetir();
                cout << "Musait masalar:\n";
                for (auto& m : masalar) {
                    cout << m->toString() << endl;
                }
                break;
            }
            case 9: {
                string tarih;
                cout << "Tarih (YYYY-MM-DD): "; cin >> tarih;
                cout << "Ciro: " << servis.gunlukCiroHesapla(tarih) << " TL\n";
                break;
            }
            case 10: {
                int limit;
                cout << "Kac yemek listelensin? "; cin >> limit;
                auto populer = servis.enPopulerYemekler(limit);
                cout << "Populer yemekler:\n";
                for (auto& y : populer) {
                    cout << y->toString() << endl;
                }
                break;
            }
            case 11: {
                int garson_id;
                cout << "Garson ID: "; cin >> garson_id;
                auto p = servis.garsonPerformansi(garson_id);
                cout << "Siparis: " << p.toplam_siparis
                     << ", Ciro: " << p.toplam_ciro
                     << ", Ortalama: " << p.ortalama_siparis << endl;
                break;
            }
            case 0:
                cout << "Cikis yapiliyor...\n";
                break;
            default:
                cout << "Gecersiz secim!\n";
        }
    } while (secim != 0);

    return 0;
}