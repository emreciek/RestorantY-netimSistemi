/**
 * @file TarihUtils.h
 * @brief Tarih donusum islemleri icin yardimci fonksiyonlar
 *
 * Bu dosya, string formatindaki tarihlerle calismayi kolaylastiran
 * DONUSUM fonksiyonlari icerir.
 *
 * NOT: Gecikme ve ceza hesaplama gibi is mantigi fonksiyonlari
 * bu dosyada yer almaz. Bunlari servis katmaninda kendiniz yaziniz.
 *
 * @author Yazilim Gelistirme I
 * @date 2024
 */

#ifndef TARIH_UTILS_H
#define TARIH_UTILS_H

#include <string>
#include <sstream>  // istringstream icin
#include <ctime>    // time_t, tm, mktime, difftime icin

/**
 * =============================================================================
 * ISTRINGSTREAM NEDIR?
 * =============================================================================
 *
 * istringstream (input string stream), bir string'i sanki bir dosya veya
 * klavye girdisiymiş gibi okumamizi saglar.
 *
 * Normal cin kullanimi:
 *   int sayi;
 *   cin >> sayi;  // Klavyeden okur
 *
 * istringstream kullanimi:
 *   string metin = "42";
 *   istringstream ss(metin);
 *   int sayi;
 *   ss >> sayi;  // String'den okur, sayi = 42 olur
 *
 * ORNEK - Tarih Ayristirma:
 *   string tarih = "2024-12-15";
 *   istringstream ss(tarih);
 *
 *   int yil, ay, gun;
 *   char ayrac;  // '-' karakterini tutmak icin
 *
 *   ss >> yil;    // "2024" okunur, yil = 2024
 *   ss >> ayrac;  // "-" okunur, ayrac = '-'
 *   ss >> ay;     // "12" okunur, ay = 12
 *   ss >> ayrac;  // "-" okunur, ayrac = '-'
 *   ss >> gun;    // "15" okunur, gun = 15
 *
 * Bu sayede "2024-12-15" string'ini yil, ay, gun degiskenlerine ayirdik.
 * =============================================================================
 */

namespace TarihUtils {

/**
 * @brief String tarihten yil, ay, gun degerlerini ayiklar
 *
 * Bu fonksiyon, "YYYY-MM-DD" formatindaki bir tarihi
 * ayri degiskenlere boler.
 *
 * @param tarih   Giris tarihi (ornek: "2024-12-15")
 * @param yil     Cikarilacak yil degeri (referans ile)
 * @param ay      Cikarilacak ay degeri (referans ile)
 * @param gun     Cikarilacak gun degeri (referans ile)
 * @return true   Basarili, false: Format hatasi
 *
 * ORNEK KULLANIM:
 *   int y, a, g;
 *   if (tarihiAyristir("2024-12-15", y, a, g)) {
 *       cout << "Yil: " << y << endl;   // 2024
 *       cout << "Ay: " << a << endl;    // 12
 *       cout << "Gun: " << g << endl;   // 15
 *   }
 */
inline bool tarihiAyristir(const std::string& tarih, int& yil, int& ay, int& gun) {
    // 1. ADIM: String'i bir akis (stream) olarak ac
    // -----------------------------------------------
    // istringstream, string'i cin gibi okumamizi saglar.
    // Yani string'in icindeki verileri tek tek cekebiliriz.
    std::istringstream ss(tarih);

    // 2. ADIM: Ayrac karakteri icin degisken
    // ----------------------------------------
    // Tarihte '-' karakterleri var, bunlari okuyup atacagiz
    char ayrac;

    // 3. ADIM: Sirayla oku
    // ----------------------
    // >> operatoru, bosluk veya farkli tipe rastlayana kadar okur
    // "2024-12-15" icin:
    //   ss >> yil    -> "2024" okunur, '-' de durur
    //   ss >> ayrac  -> '-' okunur
    //   ss >> ay     -> "12" okunur, '-' de durur
    //   ss >> ayrac  -> '-' okunur
    //   ss >> gun    -> "15" okunur
    ss >> yil >> ayrac >> ay >> ayrac >> gun;

    // 4. ADIM: Basari kontrolu
    // -------------------------
    // Eger okuma basarisiz olduysa (yanlis format), ss.fail() true doner
    // Biz basarili olup olmadigini donuyoruz, o yuzden !ss.fail()
    return !ss.fail();
}


/**
 * @brief String tarihi time_t formatina cevirir
 *
 * time_t, 1 Ocak 1970'den itibaren gecen saniye sayisidir.
 * Bu format, tarihler arasi hesaplama yapmayi kolaylastirir.
 *
 * @param tarih  String tarih (ornek: "2024-12-15")
 * @return time_t formatinda tarih, hata durumunda -1
 *
 * NOT: tm struct yapisi hakkinda
 * --------------------------------
 * tm, C'den gelen bir tarih/saat yapisidir:
 *   tm.tm_year  -> 1900'den itibaren yil (2024 icin 124)
 *   tm.tm_mon   -> Ay (0-11 arasi, Ocak=0, Aralik=11)
 *   tm.tm_mday  -> Ayin gunu (1-31)
 *   tm.tm_hour  -> Saat (0-23)
 *   tm.tm_min   -> Dakika (0-59)
 *   tm.tm_sec   -> Saniye (0-59)
 */
inline time_t stringToTime(const std::string& tarih) {
    int yil, ay, gun;

    // Tarihi ayristir
    if (!tarihiAyristir(tarih, yil, ay, gun)) {
        return -1;  // Hata durumu
    }

    // tm struct'ini olustur ve sifirla
    std::tm tm = {};

    // DIKKAT: tm_year 1900'den itibaren sayar
    // Ornek: 2024 yili icin tm_year = 2024 - 1900 = 124
    tm.tm_year = yil - 1900;

    // DIKKAT: tm_mon 0'dan baslar (Ocak = 0, Subat = 1, ..., Aralik = 11)
    // Ornek: Aralik (12) icin tm_mon = 12 - 1 = 11
    tm.tm_mon = ay - 1;

    // tm_mday normal (1-31)
    tm.tm_mday = gun;

    // mktime: tm yapisini time_t'ye cevirir
    return std::mktime(&tm);
}


/**
 * @brief Iki tarih arasindaki gun farkini hesaplar
 *
 * @param tarih1  Baslangic tarihi (ornek: "2024-11-01")
 * @param tarih2  Bitis tarihi (ornek: "2024-11-25")
 * @return Gun farki (tarih2 - tarih1)
 *
 * ORNEK:
 *   int fark = gunFarki("2024-11-01", "2024-11-25");
 *   // fark = 24 gun
 *
 * NASIL CALISIR?
 * 1. Her iki tarihi time_t'ye (saniye) cevir
 * 2. difftime ile saniye farkini al
 * 3. Saniyeyi gune cevir (/ 86400)
 *    - 1 gun = 24 saat = 24 * 60 dakika = 24 * 60 * 60 saniye = 86400 saniye
 */
inline int gunFarki(const std::string& tarih1, const std::string& tarih2) {
    // Tarihleri time_t'ye cevir
    time_t t1 = stringToTime(tarih1);
    time_t t2 = stringToTime(tarih2);

    // Hata kontrolu
    if (t1 == -1 || t2 == -1) {
        return 0;
    }

    // difftime: iki time_t arasindaki farki SANIYE olarak verir
    double saniyeFarki = std::difftime(t2, t1);

    // Saniyeyi gune cevir
    // 1 gun = 60 saniye * 60 dakika * 24 saat = 86400 saniye
    const int SANIYE_PER_GUN = 60 * 60 * 24;

    return static_cast<int>(saniyeFarki / SANIYE_PER_GUN);
}


/**
 * @brief time_t degerini string tarih formatina cevirir
 *
 * @param zaman  time_t formatinda tarih
 * @return String tarih (YYYY-MM-DD formatinda)
 *
 * ORNEK:
 *   time_t simdi = time(nullptr);
 *   string tarih = timeToString(simdi);
 *   // tarih = "2024-12-01"
 */
inline std::string timeToString(time_t zaman) {
    // time_t'yi tm struct'ina cevir
    std::tm* tmPtr = std::localtime(&zaman);

    // String olarak formatla
    // ostringstream, istringstream'in tersi - degiskenleri string'e yazar
    std::ostringstream ss;

    // Yili geri cevir (1900 ekle)
    ss << (tmPtr->tm_year + 1900) << "-";

    // Ay icin 2 basamak (01, 02, ..., 12)
    if (tmPtr->tm_mon + 1 < 10) ss << "0";
    ss << (tmPtr->tm_mon + 1) << "-";

    // Gun icin 2 basamak (01, 02, ..., 31)
    if (tmPtr->tm_mday < 10) ss << "0";
    ss << tmPtr->tm_mday;

    return ss.str();
}


/**
 * @brief Bugunun tarihini string olarak dondurur
 *
 * @return Bugunun tarihi (YYYY-MM-DD formatinda)
 *
 * ORNEK:
 *   string bugun = bugunTarihi();
 *   // bugun = "2024-12-01" (calistirildigi gune gore)
 */
inline std::string bugunTarihi() {
    time_t simdi = std::time(nullptr);
    return timeToString(simdi);
}


/**
 * @brief Bir tarihe belirli gun ekler
 *
 * @param tarih     Baslangic tarihi (YYYY-MM-DD)
 * @param gunSayisi Eklenecek gun sayisi
 * @return Yeni tarih (YYYY-MM-DD formatinda)
 *
 * ORNEK:
 *   string yeniTarih = gunEkle("2024-11-01", 14);
 *   // yeniTarih = "2024-11-15"
 */
inline std::string gunEkle(const std::string& tarih, int gunSayisi) {
    time_t baslangic = stringToTime(tarih);

    if (baslangic == -1) {
        return "";
    }

    // Gun sayisini saniyeye cevir ve ekle
    const int SANIYE_PER_GUN = 60 * 60 * 24;
    time_t sonuc = baslangic + (gunSayisi * SANIYE_PER_GUN);

    return timeToString(sonuc);
}

} // namespace TarihUtils

#endif // TARIH_UTILS_H
