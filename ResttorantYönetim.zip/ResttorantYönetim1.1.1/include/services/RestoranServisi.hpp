#ifndef RESTORAN_SERVISI_HPP
#define RESTORAN_SERVISI_HPP

#include <memory>
#include <vector>
#include <string>
#include "../repositories/Depo.hpp"
#include "../entities/Masa.hpp"
#include "../entities/Garson.hpp"
#include "../entities/MenuKategori.hpp"
#include "../entities/MenuItem.hpp"
#include "../entities/Siparis.hpp"
#include "../entities/SiparisKalemi.hpp"
#include "../entities/Rezervasyon.hpp"

struct GarsonPerformans {
    int toplam_siparis;
    double toplam_ciro;
    double ortalama_siparis;
};

class RestoranServisi {
private:
    Depo<Masa>& _masaDepo;
    Depo<Garson>& _garsonDepo;
    Depo<MenuKategori>& _kategoriDepo;
    Depo<MenuItem>& _menuItemDepo;
    Depo<Siparis>& _siparisDepo;
    Depo<SiparisKalemi>& _siparisKalemiDepo;
    Depo<Rezervasyon>& _rezervasyonDepo;

public:
    RestoranServisi(
        Depo<Masa>& masaDepo, Depo<Garson>& garsonDepo,
        Depo<MenuKategori>& kategoriDepo, Depo<MenuItem>& menuItemDepo,
        Depo<Siparis>& siparisDepo, Depo<SiparisKalemi>& siparisKalemiDepo,
        Depo<Rezervasyon>& rezervasyonDepo
    );

    ~RestoranServisi() = default;

    void masaEkle(int numara, int kapasite, const std::string& konum);
    void menuItemEkle(const std::string& ad, const std::string& aciklama, double fiyat, int kategori_id, int hazirlik_suresi);
    int siparisOlustur(int masa_id, int garson_id);
    void sipariseItemEkle(int siparis_id, int menu_item_id, int miktar, const std::string& notlar = "");
    void siparisKapat(int siparis_id);
    std::string hesapYazdir(int siparis_id);
    void rezervasyonYap(int masa_id, const std::string& musteri_adi, const std::string& telefon, const std::string& tarih_saat, int kisi_sayisi);
    std::vector<std::shared_ptr<Masa>> musaitMasalariGetir();
    double gunlukCiroHesapla(const std::string& tarih);
    std::vector<std::shared_ptr<MenuItem>> enPopulerYemekler(int limit);
    GarsonPerformans garsonPerformansi(int garson_id);
};

#endif
