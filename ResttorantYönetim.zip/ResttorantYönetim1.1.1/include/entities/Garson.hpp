#ifndef GARSON_HPP
#define GARSON_HPP

#include <string>

class Garson {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, sicil_no, ad_soyad, telefon, vardiya
    int id;
    std::string sicilNo;
    std::string adSoyad;
    std::string telefon;
    std::string vardiya;

public:
    // Varsayılan ilklendirici
    Garson();

    // Parametreli ilklendirici
    Garson(int id, const std::string& sicil_no, const std::string& ad_soyad,
           const std::string& telefon, const std::string& vardiya);

    // Kopya ilklendirici
    Garson(const Garson& other);

    // Sonlandırıcı
    ~Garson();

    // Getter VE Setterlar
    int getId() const;
    std::string getSicilNo() const;
    std::string getAdSoyad() const;
    std::string getTelefon() const;
    std::string getVardiya() const;

    void setId(int id);
    void setSicilNo(const std::string& sicilNo);
    void setAdSoyad(const std::string& adSoyad);
    void setTelefon(const std::string& telefon);
    void setVardiya(const std::string& vardiya);

    // Depo şablonu için zorunlu metod
    int get_id() const;

    // Debug amaçlı
    std::string toString() const;
};

#endif // GARSON_HPP