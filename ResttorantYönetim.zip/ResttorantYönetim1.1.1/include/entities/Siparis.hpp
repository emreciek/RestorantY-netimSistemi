#ifndef SIPARIS_HPP
#define SIPARIS_HPP

#include <string>

class Siparis {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, masa_id, garson_id, tarih_saat, durum, toplam
    int id;
    int masa_id;
    int garson_id;
    std::string tarih_saat;
    std::string durum;
    double toplam;

public:
    // Varsayılan ilklendirici
    Siparis();

    // Parametreli ilklendirici
    Siparis(int id, int masa_id, int garson_id, const std::string& tarih_saat,
            const std::string& durum, double toplam = 0.0);

    // Kopya ilklendirici
    Siparis(const Siparis& other);

    // Sonlandırıcı
    ~Siparis();
    //Getter ve Setterlar
    int getId() const;
    int getMasaId() const;
    int getGarsonId() const;
    std::string getTarihSaat() const;
    std::string getDurum() const;
    double getToplam() const;
    void setId(int id);
    void setToplam(double toplam);
    void setMasaId(int masa_id);
    void setGarsonId(int garsonId);
    void setTarihSaat(const std::string& tarih_saat);
    void setDurum(const std::string& durum);

    // Depo şablonu için zorunlu metod
    int get_id() const;
    //Debug için gerekli alan
    std::string toString() const;
};

#endif // SIPARIS_HPP
