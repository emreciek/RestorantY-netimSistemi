#ifndef SIPARIS_KALEMI_HPP
#define SIPARIS_KALEMI_HPP

#include <string>

class SiparisKalemi {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, siparis_id, menu_item_id, miktar, notlar
    int id;
    int siparis_id;
    int menu_item_id;
    int miktar;
    std::string notlar;

public:
    // Varsayılan ilklendirici
    SiparisKalemi();

    // Parametreli ilklendirici
    SiparisKalemi(int id, int siparis_id, int menu_item_id, int miktar, const std::string& notlar = "");

    // Kopya ilklendirici
    SiparisKalemi(const SiparisKalemi& other);

    // Sonlandırıcı
    ~SiparisKalemi();
    //Getter ve Setterlar
    int getId() const;
    int getSiparisId() const;
    int getMenuItemId() const;
    int getMiktar() const;
    std::string getNotlar() const;
    void setId(int id);
    void setSiparisId(int siparis_id);
    void setMenuItemId(int menu_item_id);
    void setMiktar(int miktar);
    void setNotlar(const std::string& notlar);
    // Depo şablonu için zorunlu metod
    int get_id() const;
    //Debug İçin gerkli alan
    std::string toString() const;
};

#endif // SIPARIS_KALEMI_HPP
