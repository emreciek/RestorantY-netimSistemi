#ifndef MENU_KATEGORI_HPP
#define MENU_KATEGORI_HPP

#include <string>

class MenuKategori {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, ad, aciklama
    int id;
    std::string ad;
    std::string aciklama;

public:
    // Varsayılan ilklendirici
    MenuKategori();

    // Parametreli ilklendirici
    MenuKategori(int id, const std::string& ad, const std::string& aciklama);

    // Kopya ilklendirici
    MenuKategori(const MenuKategori& other);
    //Getter ve Setterlar
    int getId() const;
    std::string getAd() const;
    std::string getAciklama() const;
    void setId(int id);
    void setAd(const std::string& ad);
    void setAciklama(const std::string& aciklama);
    // Sonlandırıcı
    ~MenuKategori();

    // Depo şablonu için zorunlu metod
    int get_id() const;
    //Debug için gerekli alan
    std::string toString() const;
};

#endif // MENU_KATEGORI_HPP
