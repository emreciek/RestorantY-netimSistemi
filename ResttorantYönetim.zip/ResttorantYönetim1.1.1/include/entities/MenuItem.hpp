#ifndef MENU_ITEM_HPP
#define MENU_ITEM_HPP

#include <string>

class MenuItem {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, ad, aciklama, fiyat, kategori_id, hazirlik_suresi
    int id;
    std::string ad;
    std::string aciklama;
    double fiyat;
    int kategori_id;
    int hazirlik_suresi;

public:
    // Varsayılan ilklendirici
    MenuItem();

    // Parametreli ilklendirici
    MenuItem(int id, const std::string& ad, const std::string& aciklama,
             double fiyat, int kategori_id, int hazirlik_suresi);

    // Kopya ilklendirici
    MenuItem(const MenuItem& other);

    // Sonlandırıcı
    ~MenuItem();
    //Getter ve Setterlar
    int getId() const;
    std::string getAd() const;
    std::string getAciklama() const;
    double getFiyat() const;
    int getKategoriId() const;
    int getHazirlikSuresi() const;
    void setId(int id);
    void setAd(const std::string& ad);
    void setAciklama(const std::string& aciklama);
    void setFiyat(double fiyat);
    void setKategoriId(int kategori_id);
    void setHazirlikSuresi(int hazirlik_suresi);
    // Depo şablonu için zorunlu metod
    int get_id() const;
    //Debug için gerekli alan
    std::string toString() const;
};

#endif // MENU_ITEM_HPP
