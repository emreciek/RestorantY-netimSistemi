#ifndef REZERVASYON_HPP
#define REZERVASYON_HPP

#include <string>

class Rezervasyon {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, masa_id, musteri_adi, telefon, tarih_saat, kisi_sayisi
    int id;
    int masa_id;
    std::string musteri_adi;
    std::string telefon;
    std::string tarih_saat;
    int kisi_sayisi;

public:
    // Varsayılan ilklendirici
    Rezervasyon();

    // Parametreli ilklendirici
    Rezervasyon(int id, int masa_id, const std::string& musteri_adi, const std::string& telefon,
                const std::string& tarih_saat, int kisi_sayisi);

    // Kopya ilklendirici
    Rezervasyon(const Rezervasyon& other);
    //Getter ve Setterlar
    int getId() const;
    int getMasaId() const;
    std::string getMusteriAdi() const;
    std::string getTelefon() const;
    std::string getTarihSaat() const;
    int getKisiSayisi() const;
    void setId(int id);
    void setMasaId(int masa_id);
    void setMusteriAdi(const std::string& musteri_adi);
    void setTelefon(const std::string& telefon);
    void setTarihSaat(const std::string& tarih_saat);
    void setKisiSayisi(int kisi_sayisi);
    // Sonlandırıcı
    ~Rezervasyon();

    // Depo şablonu için zorunlu metod
    int get_id() const;
    //Debug için gerekli alan
    std::string toString() const;
};

#endif // REZERVASYON_HPP
