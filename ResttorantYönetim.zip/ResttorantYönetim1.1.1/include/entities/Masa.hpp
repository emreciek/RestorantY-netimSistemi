#ifndef MASA_HPP
#define MASA_HPP

#include <string>

class Masa {
private:
    // TODO: Üye değişkenleri tanımlayın
    // - id, numara, kapasite, konum, durum
    int id;
    int numara;
    int kapasite;
    std::string konum;
    std::string durum;

public:
    // Varsayılan ilklendirici
    Masa();

    // Parametreli ilklendirici
    Masa(int id, int numara, int kapasite, const std::string& konum, const std::string& durum);

    // Kopya ilklendirici
    Masa(const Masa& other);

    // Sonlandırıcı
    ~Masa();
    //Getter Ve Setterlar
    int getId() const;
    int getNumara() const;
    int getKapasite() const;
    std::string getKonum() const;
    std::string getDurum() const;
    void setId(int id);
    void setNumara(int numara);
    void setKapasite(int kapasite);
    void setKonum(const std::string& konum);
    void setDurum(const std::string& durum);
    // Depo şablonu için zorunlu metod
    int get_id() const;
    //Debug İçin Gerekli alan
    std::string toString() const;
};

#endif // MASA_HPP
