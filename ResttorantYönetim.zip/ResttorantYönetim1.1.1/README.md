# Proje 05_04: Restoran Yönetim Sistemi

## Proje Tanımı

Bu proje, bir restoranın masa, sipariş ve rezervasyon yönetim sistemini simüle eder. Sistem, masa düzeni, menü yönetimi, sipariş takibi ve garson performans raporlamasını kapsar.

Proje, **çok katmanlı mimari (3-tier architecture)** prensiplerine uygun olarak tasarlanmıştır.

## Varlık Tanımları

### 1. Masa
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| numara | int | Masa numarası |
| kapasite | int | Kişi kapasitesi |
| konum | string | Konum (İç/Dış/Teras) |
| durum | string | Durum (Boş/Dolu/Rezerve) |

### 2. Garson
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| sicil_no | string | Sicil numarası |
| ad_soyad | string | Ad soyad |
| telefon | string | Telefon |
| vardiya | string | Vardiya (Sabah/Akşam) |

### 3. MenuKategori
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| ad | string | Kategori adı |
| aciklama | string | Açıklama |

### 4. MenuItem
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| ad | string | Yemek adı |
| aciklama | string | Açıklama |
| fiyat | double | Fiyat |
| kategori_id | int | Kategori referansı |
| hazirlik_suresi | int | Hazırlık süresi (dk) |

### 5. Siparis
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| masa_id | int | Masa referansı |
| garson_id | int | Garson referansı |
| tarih_saat | string | Sipariş zamanı |
| durum | string | Durum (Açık/Hazırlanıyor/Tamamlandı) |
| toplam | double | Toplam tutar |

### 6. SiparisKalemi
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| siparis_id | int | Sipariş referansı |
| menu_item_id | int | Menü item referansı |
| miktar | int | Miktar |
| notlar | string | Özel notlar |

### 7. Rezervasyon
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | int | Benzersiz kimlik |
| masa_id | int | Masa referansı |
| musteri_adi | string | Müşteri adı |
| telefon | string | Telefon |
| tarih_saat | string | Rezervasyon zamanı |
| kisi_sayisi | int | Kişi sayısı |

## Servis İşlemleri (11 Adet)

1. **masaEkle()** - Yeni masa ekleme
2. **menuItemEkle()** - Menüye yemek ekleme
3. **siparisOlustur()** - Yeni sipariş başlatma
4. **sipariseItemEkle()** - Siparişe yemek ekleme
5. **siparisKapat()** - Siparişi kapatma
6. **hesapYazdir()** - Hesap fişi oluşturma
7. **rezervasyonYap()** - Rezervasyon oluşturma
8. **musaitMasalariGetir()** - Boş masaları listeleme
9. **gunlukCiroHesapla()** - Günlük ciro raporu
10. **enPopulerYemekler()** - En çok sipariş edilen yemekler
11. **garsonPerformansi()** - Garson performans raporu

## Derleme ve Çalıştırma

```bash
mkdir build && cd build
cmake ..
make
./restoran_yonetim
```
